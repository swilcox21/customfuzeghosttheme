import React, { useState, useEffect } from 'react';

export const ReactApp = () => {

    return (
        <>
            <div>HI BILL</div>
        </>
    );
};